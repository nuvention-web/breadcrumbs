(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;


})();

//# sourceMappingURL=methods.coffee.js.map
