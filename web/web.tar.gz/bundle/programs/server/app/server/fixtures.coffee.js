(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var admin;

if (Meteor.users.find().count() === 0) {
  admin = Assets.getText('admin').split(',');
  Accounts.createUser({
    username: admin[0],
    email: admin[1],
    password: admin[2],
    profile: {
      first_name: admin[3],
      last_name: admin[4]
    }
  });
}

})();

//# sourceMappingURL=fixtures.coffee.js.map
