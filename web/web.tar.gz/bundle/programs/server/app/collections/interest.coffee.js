(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Interest = new Mongo.Collection('interest');

})();

//# sourceMappingURL=interest.coffee.js.map
