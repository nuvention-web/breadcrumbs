'use strict';

console.log('\'Allo \'Allo! Option');
